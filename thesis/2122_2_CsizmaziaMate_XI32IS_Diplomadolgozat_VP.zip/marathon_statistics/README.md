# BSZM eredményeit elemző kiértékelés

